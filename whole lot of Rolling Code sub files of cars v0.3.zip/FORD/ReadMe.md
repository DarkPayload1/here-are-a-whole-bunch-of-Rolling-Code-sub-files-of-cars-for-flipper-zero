# Remote Blocker (Ford)
These signals can force Ford cars to block their remotes. The vehicles can still be accessed manually but to use the remote again you need to pull and reconnect the cars 12V battery.

[From xfmxx](https://github.com/xfmxx)
