 NO this WILL NOT open a Rx8, you CAN NOT "troll" Mazda owners and don't be that dick anyway.<br>
 This is to help somebody to decode a protocol to bruteforce them or for testing purposes.
